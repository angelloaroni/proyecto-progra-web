import { useState } from "react";
import objetoService from "../../services/objeto.service";
import getErrorMessage from "../../services/getErrorMessage";
import "./RegisterForm.css";

const CATEGORIAS = ["Electrónicos", "Deportes", "Útiles Estudiantiles", "Prendas de Vestir", "Otros"];
const NUEVA_CATEGORIA = "__nueva_categoria__";

const ICONOS = [
  { valor: "⌨️", etiqueta: "⌨️ Teclado" },
  { valor: "🎾", etiqueta: "🎾 Deportes" },
  { valor: "📘", etiqueta: "📘 Cuaderno / Libro" },
  { valor: "🧥", etiqueta: "🧥 Ropa" },
  { valor: "🎒", etiqueta: "🎒 Mochila" },
  { valor: "📱", etiqueta: "📱 Celular / Gadget" },
];
const NUEVO_ICONO = "__nuevo_icono__";

const FORM_INICIAL = { nombre: "", categoria: "", descripcion: "", icono: "⌨️" };

const RegisterForm = () => {
  const [form, setForm] = useState(FORM_INICIAL);
  const [categoriaPersonalizada, setCategoriaPersonalizada] = useState(false);
  const [iconoPersonalizado, setIconoPersonalizado] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await objetoService.crear(form);
      alert(response.message);
      if (response.success) {
        setForm(FORM_INICIAL);
        setCategoriaPersonalizada(false);
        setIconoPersonalizado(false);
      }
    } catch (error) {
      alert(getErrorMessage(error, "No se pudo publicar el objeto."));
    }
  };

  const handleCategoriaChange = (e) => {
    const valor = e.target.value;
    if (valor === NUEVA_CATEGORIA) {
      setCategoriaPersonalizada(true);
      setForm({ ...form, categoria: "" });
    } else {
      setForm({ ...form, categoria: valor });
    }
  };

  const cancelarCategoriaNueva = () => {
    setCategoriaPersonalizada(false);
    setForm({ ...form, categoria: "" });
  };

  const handleIconoChange = (e) => {
    const valor = e.target.value;
    if (valor === NUEVO_ICONO) {
      setIconoPersonalizado(true);
      setForm({ ...form, icono: "" });
    } else {
      setForm({ ...form, icono: valor });
    }
  };

  const cancelarIconoNuevo = () => {
    setIconoPersonalizado(false);
    setForm({ ...form, icono: ICONOS[0].valor });
  };

  return (
    <div className="box register-box">
      <h2>Registrar Nuevo Objeto Perdido</h2>
      <form className="flex-column" onSubmit={handleSubmit}>
        <div className="register-form-row">
          <div className="form-group">
            <label>Nombre del objeto</label>
            <input
              type="text"
              placeholder="Ej: Casaca negra con logo azul"
              value={form.nombre}
              onChange={(e) => setForm({ ...form, nombre: e.target.value })}
              required
            />
          </div>
          <div className="form-group">
            <label>Categoría</label>
            {categoriaPersonalizada ? (
              <div className="custom-field-row">
                <input
                  type="text"
                  placeholder="Escribe el nombre de la nueva categoría"
                  value={form.categoria}
                  onChange={(e) => setForm({ ...form, categoria: e.target.value })}
                  required
                  autoFocus
                />
                <button type="button" className="link-btn" onClick={cancelarCategoriaNueva}>
                  Cancelar
                </button>
              </div>
            ) : (
              <select
                value={form.categoria}
                onChange={handleCategoriaChange}
                required
              >
                <option value="" disabled>Selecciona una categoría</option>
                {CATEGORIAS.map((categoria) => (
                  <option key={categoria} value={categoria}>{categoria}</option>
                ))}
                <option value={NUEVA_CATEGORIA}>+ Agregar nueva categoría</option>
              </select>
            )}
          </div>
        </div>
        <div className="form-group">
          <label>Descripción detallada</label>
          <textarea
            rows="3"
            placeholder="¿Dónde fue encontrado? ¿Qué características tiene?"
            value={form.descripcion}
            onChange={(e) => setForm({ ...form, descripcion: e.target.value })}
            required
          />
        </div>
        <div className="form-group icon-select-group">
          <label>Ícono representativo</label>
          {iconoPersonalizado ? (
            <div className="custom-field-row">
              <input
                type="text"
                maxLength="4"
                placeholder="Pega o escribe un emoji, ej: 🔑"
                value={form.icono}
                onChange={(e) => setForm({ ...form, icono: e.target.value })}
                required
                autoFocus
              />
              <button type="button" className="link-btn" onClick={cancelarIconoNuevo}>
                Cancelar
              </button>
            </div>
          ) : (
            <select
              value={form.icono}
              onChange={handleIconoChange}
            >
              {ICONOS.map(({ valor, etiqueta }) => (
                <option key={valor} value={valor}>{etiqueta}</option>
              ))}
              <option value={NUEVO_ICONO}>+ Agregar otro emoji</option>
            </select>
          )}
        </div>
        <button type="submit" className="btn publish-btn">Publicar Objeto</button>
      </form>
    </div>
  );
};

export default RegisterForm;