import RegisterForm from "./RegisterForm";
import ClaimsTable from "./ClaimsTable";
import UsersTable from "./UsersTable";

export default function AdminView({ reclamos, usuarios, onRegistrar, onResolver, onToggleAcceso }) {
  return (
    <section className="view active">
      <RegisterForm onRegistrar={onRegistrar} />
      <ClaimsTable reclamos={reclamos} onResolver={onResolver} />
      <UsersTable usuarios={usuarios} onToggleAcceso={onToggleAcceso} />
    </section>
  );
}